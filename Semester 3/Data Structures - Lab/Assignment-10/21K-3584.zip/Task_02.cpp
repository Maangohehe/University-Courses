#include <iostream>
using namespace std;

class MinHeapNode
{
    char var;
    unsigned int freq;
    MinHeapNode *left, *right;
    friend class MinHeapHuffman;
    MinHeapNode()
    {
        var = '\0';
        freq = 0;
        left = right = nullptr;
    }
};

class MinHeapHuffman
{
    unsigned int size, capacity;
    MinHeapNode **arr;
    void swap_nodes(MinHeapNode *x, MinHeapNode *y)
    {
        MinHeapNode *temp;
        *temp = *x;
        *x = *y;
        *y = *temp;
    }
    void min_heapify(MinHeapHuffman *obj, int index)
    {
        int small, left, right;
        small = index;
        left = 2 * index + 1;
        right = 2 * index + 2;
        if (left < obj->size && obj->arr[left]->freq < obj->arr[small]->freq)
            small = left;
        if (right < obj->size && obj->arr[right]->freq < obj->arr[small]->freq)
        {
            small = right;
        }
        if (small != index)
        {
            swap_nodes(obj->arr[small], obj->arr[index]);
            min_heapify(obj, small);
        }
    }
    MinHeapNode *give_min(MinHeapHuffman *Min)
    {
        MinHeapNode *temp = Min->arr[0];
        Min->arr[0] = Min->arr[Min->size - 1];
        --Min->size;
        min_heapify(Min, 0);
        return temp;
    }
    bool size_is(MinHeapHuffman* minh)
    {
        return (minh->size == 1);
    }
    MinHeapNode *insert(char data, unsigned int freq)
    {
        MinHeapNode *temp = new MinHeapNode();
        temp->left = temp->right = nullptr;
        temp->var = data;
        temp->freq = freq;
        return temp;
    }
    MinHeapHuffman *create_min(unsigned capacity)
    {
        MinHeapHuffman *minH;
        minH->capacity = capacity;
        minH->size = 0;
        minH->arr = new MinHeapNode *;
        return minH;
    }
    void build_helper(MinHeapHuffman *minh)
    {
        int n = minh->size - 1;
        for (int i = (n - 1) / 2; i >= 0; --i)
        {
            min_heapify(minh, i);
        }
    }
    MinHeapHuffman *build_minheap(char data[], int freqe[], int size)
    {
        MinHeapHuffman *minh = create_min(size);
        for (int i = 0; i < size; i++)
        {
            minh->arr[i] = insert(data[i], freqe[i]);
        }
        minh->size = size;
        build_helper(minh);
        return minh;
    }
    void add_node(MinHeapHuffman* minh, MinHeapNode* minhNode)
    {
        ++minh->size;
        int i = minh->size - 1;
        while (i && minhNode->freq < minh->arr[(i-1)/2]->freq)
        {
            minh->arr[i] = minh->arr[(i-1)/2];
            i = (i-1)/2;
        }
        minh->arr[i] = minhNode;
    }
    MinHeapNode *buildHuff(char data[], int freqe[], int size)
    {
        MinHeapNode *left, *right, *top;
        MinHeapHuffman *minh = build_minheap(data, freqe, size);
        while(!size_is(minh))
        {
            left = give_min(minh);
            right = give_min(minh);
            top = insert('#', left->freq + right->freq);
 
            top->left = left;
            top->right = right;
 
            add_node(minh, top);
        }
        return give_min(minh);
    }
    void print_arr(int arr[], int n)
    {
        for(int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    bool is_leaf(MinHeapNode* root)
    {
        return !(root->left) && !(root->right);
    }
    void print(MinHeapNode* root, int arr[], int top)
    {
        if(root->left)
        {
            arr[top] = 0;
            print(root->left, arr, top+1);
        }
        if (root->right)
        {
            arr[top] = 1;
            print(root->right, arr, top+1);
        }
        if (is_leaf(root))
        {
            cout << root->var << ": ";
            print_arr(arr, top);
        }
    }
    void decmp(MinHeapNode** root, int n)
    {
        int i = 0;
        while (i < n)
        {
            MinHeapNode** curr = root;
            while (curr[0]->left != nullptr && curr[0]->right != nullptr)
            {
                
            }
        }
    }
public:
    void Huffman(char data[], int freqe[], int size)
    {
        MinHeapNode *root = buildHuff(data, freqe, size);
        int arr[100], top = 0;
        print(root, arr, top);
    }
    void huffDecompress()
    {
        int n = sizeof(arr);
        decmp(arr, n);
    }
};

int main(void)
{
    char arr[] = {'C', 'l', 'a', 's', 's', ' ', 'B', 'C', 'Y','-', '3', 'A'};
    int freq[] = {2, 1, 2, 2, 1, 1, 2, 1, 1, 1, 2};
    int size = sizeof(arr)/sizeof(char);
    MinHeapHuffman h1;
    h1.Huffman(arr, freq, size);

}