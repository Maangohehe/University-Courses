#include <iostream>
#include <cstring>
using namespace std;

class MaxHeap
{
    int *arr, capacity, length;
    MaxHeap(int N)
    {
        arr = new int[N];
        capacity = N;
        length = 0;
    }
    MaxHeap()
    {
        arr = 0x0;
        capacity = -1;
        length = -1;
    }
    void init_heap(int N)
    {
        arr = new int[N];
        capacity = N;
        length = 0;
    }
    void sift_down(int index)
    {
        //Compare with left and right child
        int largest_child = (2*index)+1, last = length;
        while (largest_child < last)
        {
            if (largest_child < last && arr[largest_child] < arr[largest_child+1])
            {
                largest_child++;
            }
            if (arr[index] < arr[largest_child])
            {
                swap(arr[index], arr[largest_child]);
                index = largest_child;
                largest_child = (2*index)+1;
            }
            else largest_child = last+1;
        }
    }
    int Delete()
    {
        int data;
        data = arr[0];
        arr[0] = arr[length-1];
        length--;
        sift_down(0);
        return data;
    }
        int get_length()
        {
            return length;
        }
        void insertMaxHeap(int data)
        {
            length++;
            int i = length - 1;
            if (i > length)
            {
                length--;
                return;
            } 
            while (i > 0 && data > arr[(i-1)/2])
            {
                arr[i] = arr[(i-1)/2];
                i = (i-1)/2;
            }
            arr[i] = data;
        }
        int DeleteMaxHeap(int data)
        {
            if (length == 0) return 0;
            int i = 0;
            for (i; i < length; i++)
            {
                if (arr[i] == data) break;
            }
            data = arr[i];
            arr[i] = arr[length-1];
            length--;
            sift_down(i);
            return data;
        }
        void printMaxHeap()
        {
            for (int i = 0; i < length; i++) cout << arr[i] << " ";
            cout << endl;
        }
        bool ReHeapify(int N)
        {
            int temp[N];
            for (int i = 0; i < N; i++)
            {
                temp[i] = arr[i];
            }
            length = 0;
            memset(arr, 0, sizeof(arr));
            for (int i = 0; i < N; i++)
            {
                insertMaxHeap(temp[i]);
            }
            for (int i = 0; i < N; i++)
            {
                if (temp[i] != arr[i]) return false;
            }
            return true;
        }
        void buildHeap(int *sortedArr, int N)
        {
            for (int i = 0; i < N; i++)
            {
                sortedArr[i] = Delete(); 
            }
        }
    friend class PriorityQueue;
};

class PriorityQueue
{
    MaxHeap M1;
    public:
        PriorityQueue(int N)
        {
            M1.init_heap(N);
        }
        void insert(int data)
        {
            M1.insertMaxHeap(data);
        }
        void print_queue()
        {
            for (int i = 0; i < M1.length; i++)
            {
                cout << M1.arr[i] << " ";
            }
            cout << endl;
        }
        bool dec_elem(int index)
        {
            --M1.arr[index];
            return M1.ReHeapify(M1.length);
        }
};

int main(void)
{
    int N = 4;
    PriorityQueue p1(N);
    int tries = 0;
    int arr[] = {3, 1, 2, 1};
    for (int i = 0; i < N; i++)
    {
        p1.insert(arr[i]);
    }
    p1.print_queue();
    while (1)
    {
        int x;
        cout << "Input index of element to decrement: ";
        cin >> x;
        cout << endl;
        if(p1.dec_elem(x))
        {
            tries++;
            cout << "You can decrement again\n";
        }
        else
        {
            cout << "Max numbers of steps are: " << tries << endl;
            break;
        }
    }
    p1.print_queue();
}