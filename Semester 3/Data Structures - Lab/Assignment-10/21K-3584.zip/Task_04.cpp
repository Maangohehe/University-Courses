#include <iostream>
using namespace std;

class MinHeap
{
    int *arr, capacity, length;
    void sift_up(int index)
    {
        //Compare with left and right child
        int largest_child = (2*index)+1, last = length;
        while (largest_child < last)
        {
            if (largest_child < last && arr[largest_child] > arr[largest_child+1])
            {
                largest_child++;
            }
            if (arr[index] > arr[largest_child])
            {
                swap(arr[index], arr[largest_child]);
                index = largest_child;
                largest_child = (2*index)+1;
            }
            else largest_child = last+1;
        }
    }
    int Delete()
    {
        int data;
        data = arr[0];
        arr[0] = arr[length-1];
        length--;
        sift_up(0);
        return data;
    }
    public:
        MinHeap(int N)
        {
            arr= new int[N];
            capacity = N;
            length = 0;
        }
        void insertMinHeap(int data)
        {
            length++;
            int i = length - 1;
            while (i > 0 && data < arr[(i-1)/2])
            {
                arr[i] = arr[(i-1)/2];
                i = (i-1)/2;
            }
            arr[i] = data;
        }
        void DeleteMinHeap(int data)
        {
            int i = 0;
            for (; i < length; i++)
            {
                if (arr[i] == data) break;
            }
            arr[i] = arr[length-1];
            length--;
            sift_up(i);
        }
        void printMinHeap()
        {
            for (int i = 0; i < length; i++) cout << arr[i] << " ";
            cout << endl;
        }
        void heapify(int* array, int N)
        {
            for (int i = 0; i < N; i++)
            {
                insertMinHeap(array[i]);
            }
        }

        void buildHeap(int *sortedArray, int N)
        {
            for (int i = 0; i < N; i++)
            {
                sortedArray[i] = Delete();
            }
        }
};

int main(void)
{
    MinHeap M(5);
    int N = 5;
    int arr[5] = {4, 1, 3, 9, 7};
    M.heapify(arr, N);
    printf("Sorted array is: ");
    M.buildHeap(arr, N);
    for (int x: arr)
    {
        cout << x << " ";
    }
    cout << endl;
}