#include <bits/stdc++.h>
using namespace std;

void swap_arr(int *x, int *y)
{
    int *temp;
    *temp = *x;
    *x = *y;
    *y = *temp;
}
class MaxHeap
{
    int *arr, capacity, length;
    void sift_down(int index)
    {
        //Compare with left and right child
        int largest_child = (2*index)+1, last = length;
        while (largest_child < last)
        {
            if (largest_child < last && arr[largest_child] < arr[largest_child+1])
            {
                largest_child++;
            }
            if (arr[index] < arr[largest_child])
            {
                swap(arr[index], arr[largest_child]);
                index = largest_child;
                largest_child = (2*index)+1;
            }
            else largest_child = last+1;
        }
    }
    int Delete()
    {
        int data;
        data = arr[0];
        arr[0] = arr[length-1];
        length--;
        sift_down(0);
        return data;
    }
    public:
        MaxHeap(int N)
        {
            arr = new int[N];
            capacity = N;
            length = 0;
        }
        int get_length()
        {
            return length;
        }
        void insertMaxHeap(int data)
        {
            length++;
            int i = length - 1;
            if (i > length)
            {
                length--;
                return;
            } 
            while (i > 0 && data > arr[(i-1)/2])
            {
                arr[i] = arr[(i-1)/2];
                i = (i-1)/2;
            }
            arr[i] = data;
        }
        int DeleteMaxHeap(int data)
        {
            if (length == 0) return 0;
            int i = 0;
            for (i; i < length; i++)
            {
                if (arr[i] == data) break;
            }
            data = arr[i];
            arr[i] = arr[length-1];
            length--;
            sift_down(i);
            return data;
        }
        void printMaxHeap()
        {
            for (int i = 0; i < length; i++) cout << arr[i] << " ";
            cout << endl;
        }
        void buildHeap(int *sortedArr, int N)
        {
            for (int i = 0; i < N; i++)
            {
                sortedArr[i] = Delete(); 
            }
        }
};
class MinHeap
{
    int *arr, capacity, length;
    void sift_up(int index)
    {
        while (index != 0 && arr[(index-1)/2] > arr[index])
        {
            int temp = arr[(index - 1) / 2];
            arr[(index - 1) / 2] = arr[index];
            arr[index] = temp;
            index = (index - 1) / 2;
        }
    }
    public:
        MinHeap(int N)
        {
            arr= new int[N];
            capacity = N;
            length = 0;
        }
        void insertMinHeap(int data)
        {
            length++;
            int i = length - 1;
            while (i > 0 && data < arr[(i-1)/2])
            {
                arr[i] = arr[(i-1)/2];
                i = (i-1)/2;
            }
            arr[i] = data;
        }
        void DeleteMinHeap(int data)
        {
            int i = 0;
            for (; i < length; i++)
            {
                if (arr[i] == data) break;
            }
            arr[i] = arr[length-1];
            length--;
            sift_up(i);
        }
        void printMinHeap()
        {
            for (int i = 0; i < length; i++) cout << arr[i] << " ";
            cout << endl;
        }
        
};
int main(void)
{
    MaxHeap h1(50);
    MinHeap h2(50);
    int arr[] = {35, 33, 42, 10, 19, 27, 44, 26, 31};
    int n = sizeof(arr)/sizeof(int);
    for (int i = 0; i < n; i++)
    {
        h1.insertMaxHeap(arr[i]);
    }
    cout << "Max Heap" << endl;
    h1.printMaxHeap();
    //A)
    h1.DeleteMaxHeap(42);
    h1.printMaxHeap();
    for (int i = 0; i < n; i++)
    {
        h2.insertMinHeap(arr[i]);
    }
    cout << "MinHeap" << endl;
    h2.printMinHeap();
    //B)
    h2.DeleteMinHeap(35);
    h2.printMinHeap();
    cout << "Sorted Max Heap" << endl;
    int newArr[9];
    h1.buildHeap(newArr, 8);
    for (int x:newArr)
    {
        cout << x << " ";
    }
    cout << endl;
}