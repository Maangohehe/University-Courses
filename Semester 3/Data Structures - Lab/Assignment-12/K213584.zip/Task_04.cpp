#include <iostream>
#include <cstring>
using namespace std;

#define MIN 9999999

#define VERTICES 7

int G[VERTICES][VERTICES] = {
    {0, 9, 75, 0, 0},
    {9, 0, 95, 19, 42},
    {75, 95, 0, 51, 66},
    {0, 19, 51, 0, 31},
    {0, 42, 66, 31, 0}
};

int main()
{
    int no_edge; // number of edge

    int selected[VERTICES];

    memset(selected, false, sizeof(selected));

    no_edge = 0;

    selected[0] = true;

    int x; //  row number
    int y; //  col number

    cout << "Edge"
         << " : "
         << "Weight";
    cout << endl;
    while (no_edge < VERTICES - 1)
    {

        int min = MIN;
        x = 0;
        y = 0;

        for (int i = 0; i < VERTICES; i++)
        {
            if (selected[i])
            {
                for (int j = 0; j < VERTICES; j++)
                {
                    if (!selected[j] && G[i][j])
                    {
                        if (min > G[i][j])
                        {
                            min = G[i][j];
                            x = i;
                            y = j;
                        }
                    }
                }
            }
        }
        cout << x << " - " << y << " :  " << G[x][y];
        cout << endl;
        selected[y] = true;
        no_edge++;
    }

    return 0;
}