#include <iostream>
#include <list>
#include <vector>
using namespace std;


class Graph
{
    int V; //vertex
    vector<list<int>> adj;
    public:
    Graph(int V);
    void addEdge(int v, int w);
    void BFS(int s);

};

Graph::Graph(int V)
{
    this->V = V;
    adj.resize(V);
}
void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w); // Add w to v’s list.
}
void Graph::BFS(int s)
{ // Mark all the vertices as not visited
    bool *visited = new bool[V];
    for (int i = 0; i < V; i++)
        visited[i] = false;
    // Create a queue for BFS
    list<int> queue;
    // Mark the current node as visited and enqueue it
    visited[s] = true;
    queue.push_back(s);
    // 'i' will be used to get all adjacent
    // vertices of a vertex
    list<int>::iterator i;
    while (!queue.empty())
    {
        // Dequeue a vertex from queue and print it
        s = queue.front();
        cout << s << " ";
        queue.pop_front();
        // Get all adjacent vertices of the dequeued
        // vertex s. If a adjacent has not been visited,
        // then mark it visited and enqueue it
        for (i = adj[s].begin(); i != adj[s].end(); ++i)
        {
            if (!visited[*i])
            {
                visited[*i] = true;
                queue.push_back(*i);
            }
        }
    }
}
int main(void)
{
    Graph g1(5);
    g1.addEdge(1, 3);
    g1.addEdge(0, 1);
    g1.addEdge(0, 2);
    g1.addEdge(3, 2);
    g1.addEdge(4, 1);
    g1.addEdge(3, 4);
    g1.addEdge(2, 2);
    g1.addEdge(2, 3);
    g1.addEdge(2, 4);
    g1.addEdge(1, 4);
    cout << "Breadth first traversal from node 0 is: " << endl;
    g1.BFS(0);

}