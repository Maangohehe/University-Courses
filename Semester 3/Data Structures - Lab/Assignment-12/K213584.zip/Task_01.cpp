#include <iostream>
#include <cstring>
using namespace std;
class node
{
    int data;
    node* next;
    friend class DiGraph;
    friend class UnGraph;
};

class Edge
{
    int src, des;
    friend class DiGraph;
    friend class UnGraph;
    public:
        Edge(int x, int y):src(x), des(y)
        {
        }
};

class UnGraph
{
    size_t number_of_vertices;
    node **head; //head of my vertex
    node* getNode(int des, node* head)
    {
        node* newNode = new node();
        newNode->data = des;
        newNode->next = head;
        return newNode;
    }
    public:
        UnGraph(Edge edges[], size_t n_e, size_t n_vert)
        {
            head = new node*[n_vert]; //number of vertices i want
            this->number_of_vertices = n_vert;
            memset(head, 0x0, sizeof(head));

            for (size_t i = 0; i < n_e; i++)
            {
                int src = edges[i].src;
                int des = edges[i].des;
                node* newNode = getNode(des, head[src]);
                head[src] = newNode;

                node* newNode = getNode(src, head[des]);
			    head[des] = newNode;
            }
        }
        void Printer()
        {
            for (int i = 0; i < 5; i++)
            {
                node* trav = head[i];
                while (trav != nullptr)
                {
                    cout << i;
                    cout << " -> " << trav->data << " ";
                    trav = trav->next;
                }
                cout << endl;
            }
        }
};

class DiGraph
{
    size_t number_of_vertices;
    node **head; //head of my vertex
    node* getNode(int des, node* head)
    {
        node* newNode = new node();
        newNode->data = des;
        newNode->next = head;
        return newNode;
    }
    public:
        DiGraph(Edge edges[], size_t n_e, size_t n_vert)
        {
            head = new node*[n_vert]; //number of vertices i want
            this->number_of_vertices = n_vert;
            memset(head, 0x0, sizeof(head));

            for (size_t i = 0; i < n_e; i++)
            {
                int src = edges[i].src;
                int des = edges[i].des;
                node* newNode = getNode(des, head[src]);
                head[src] = newNode;
            }
        }
        void Delete(int vert)
        {
            node* trav = head[vert-1];
            while (trav != nullptr)
            {
                if (trav->data == vert)
                {
                    delete[] trav;
                    break;
                }
                trav = trav->next;     
            }
        }
        void Printer()
        {
            for (int i = 0; i < 5; i++)
            {
                node* trav = head[i];
                if (trav == nullptr) continue;
                while (trav != nullptr)
                {
                    cout << i;
                    cout << " -> " << trav->data << " ";
                    trav = trav->next;
                }
                cout << endl;
            }
        }
};

int main(void)
{
    Edge edges[] = {
        {0, 1}, {0, 4},
        {1, 2}, {1, 4}, {1, 3},
        {2, 3},
        {3, 4},
        {4, 0}
    };
    int n_e = sizeof(edges)/sizeof(Edge);
    DiGraph graph(edges, n_e, 5);
    cout << "Deleting node 2" << endl;
    graph.Delete(2);
    graph.Printer();

}