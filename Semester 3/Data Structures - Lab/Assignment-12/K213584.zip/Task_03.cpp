#include <iostream>
#include <list>
using namespace std;

class Graph {
  int numVertices;
  list<int> *adjLists;
  bool *visited;

   public:
  Graph(int V);
  void addEdge(int src, int dest);
  void DFS(int vertex);
};

// Initialize graph
Graph::Graph(int vertices) {
  numVertices = vertices;
  adjLists = new list<int>[vertices];
  visited = new bool[vertices];
}

// Add edges
void Graph::addEdge(int src, int dest) {
  adjLists[src].push_front(dest);
}

// DFS algorithm
void Graph::DFS(int vertex) {
  visited[vertex] = true;
  list<int> adjList = adjLists[vertex];

  cout << vertex << " ";

  list<int>::iterator i;
  for (i = adjList.begin(); i != adjList.end(); ++i)
    if (!visited[*i])
      DFS(*i);
}

int main() {
  Graph g1(5);
    g1.addEdge(1, 3);
    g1.addEdge(0, 1);
    g1.addEdge(0, 2);
    g1.addEdge(3, 2);
    g1.addEdge(4, 1);
    g1.addEdge(3, 4);
    g1.addEdge(2, 2);
    g1.addEdge(2, 3);
    g1.addEdge(2, 4);
    g1.addEdge(1, 4);
    cout << "Depth first search starting from vertex 0 is: " << endl;
    g1.DFS(0);
    return 0;
}